@tool
extends Node
class_name WtTerrainMaterialApplicator

const TERRAIN_SHADER := preload("res://addons/world_transvoxel_terrain/material/wt_terrain_weighted_palette.gdshader")
const TextureFactory := preload("res://addons/world_transvoxel_terrain/material/wt_terrain_material_texture_factory.gd")
const CHECKER_TEXTURE_FORMAT := "RGBA8"
const CHECKER_TEXTURE_BYTES_PER_PIXEL := 4
const MAX_STANDARD_TEXTURE_BYTES := 4 * 1024
const QUALITY_IMPLEMENTATION := "terrain_material_texture_pipeline_v1"
const PRODUCTION_QUALITY_IMPLEMENTATION := "terrain_native_explicit_material_weights_v1"
const VISIBLE_SHADER_MODE := "native_override_world_triplanar_explicit_weight_layers"

@export var auto_apply: bool = true
@export_range(1, 30, 1) var material_audit_interval_frames: int = 1
@export_range(2, 64, 1) var texture_resolution: int = 16
@export var reference_scene_path: NodePath = ^"../WtTerrainReferenceScene"
@export var visual_mode: StringName = &"production"
@export var clean_albedo_color: Color = Color(0.72, 0.65, 0.50, 1.0)
@export var clean_albedo_texture_path: String = ""
@export_range(0.001, 1.0, 0.001) var clean_texture_world_scale: float = 0.125
@export var clean_triplanar_enabled: bool = true
@export_range(1.0, 16.0, 0.1) var clean_triplanar_blend_sharpness: float = 4.0
@export var clean_material_variation_enabled: bool = false
@export_range(0.0, 1.0, 0.01) var clean_material_variation_strength: float = 0.08

var _summary := {
	"applied": false,
	"materialized_instances": 0,
	"reapplied_instances": 0,
	"native_render_material_override": false,
	"texture_resolution": 0,
	"texture_format": CHECKER_TEXTURE_FORMAT,
	"texture_bytes": 0,
	"texture_checksum": 0,
	"shader_mode": VISIBLE_SHADER_MODE,
	"profile_shader_mode": "",
	"profile_id": "",
	"material_ids": [],
	"visual_mode": "production",
	"clean_texture_enabled": false,
	"clean_triplanar_enabled": true,
	"auto_apply_count": 0,
	"deterministic_texture": true,
	"small_texture_budget_bytes": MAX_STANDARD_TEXTURE_BYTES,
	"quality_implementation": QUALITY_IMPLEMENTATION,
	"production_quality_implementation": PRODUCTION_QUALITY_IMPLEMENTATION,
	"implementation": "terrain_addon_material_applicator",
}
var _material: ShaderMaterial
var _material_texture_resolution := 0
var _texture_checksum := 0
var _auto_apply_signature := ""
var _auto_apply_count := 0
var _audit_frame_count := 0

func _ready() -> void:
	set_process(auto_apply)

func _process(_delta: float) -> void:
	if _runtime_signature().is_empty():
		_auto_apply_signature = ""
		return
	if not _apply_if_signature_changed():
		_repair_missing_materials_if_needed()

func get_material_summary() -> Dictionary:
	return _summary.duplicate()

func get_material_quality_summary() -> Dictionary:
	var summary := get_material_summary()
	summary["quality_implementation"] = QUALITY_IMPLEMENTATION
	summary["small_texture_budget_bytes"] = MAX_STANDARD_TEXTURE_BYTES
	summary["deterministic_texture"] = true
	return summary

func apply_materials_now() -> Dictionary:
	var backend := _backend_terrain()
	if backend == null:
		_summary["applied"] = false
		return get_material_summary()
	var material := _material_instance()
	_apply_visual_mode(material)
	var native_override_set := _set_native_material_override(backend, material)
	var result := _apply_to_meshes(backend, material)
	var profile := _material_profile_summary()
	var resolved_texture_resolution := _material_texture_resolution
	var production_resolution := _production_texture_resolution(profile)
	var production_active := bool(profile.get("production_texture_pipeline", false)) and production_resolution >= 64
	_summary = {
		"applied": native_override_set or int(result.get("checked", 0)) > 0,
		"materialized_instances": int(result.get("checked", 0)),
		"reapplied_instances": int(result.get("updated", 0)),
		"native_render_material_override": native_override_set,
		"texture_resolution": resolved_texture_resolution,
		"texture_format": CHECKER_TEXTURE_FORMAT,
		"texture_bytes": _texture_bytes(resolved_texture_resolution),
		"texture_checksum": _texture_checksum,
		"shader_mode": VISIBLE_SHADER_MODE,
		"profile_shader_mode": str(profile.get("shader_mode", "")),
		"profile_id": str(profile.get("profile_id", "unknown")),
		"material_ids": Array(profile.get("material_ids", [])),
		"material_profile_configured": bool(profile.get("configured", false)),
		"auto_apply_count": _auto_apply_count,
		"auto_apply_signature": _auto_apply_signature,
		"deterministic_texture": true,
		"small_texture_budget_bytes": MAX_STANDARD_TEXTURE_BYTES,
		"material_instance_id": material.get_instance_id(),
		"quality_implementation": QUALITY_IMPLEMENTATION,
		"production_quality_implementation": PRODUCTION_QUALITY_IMPLEMENTATION,
		"production_texture_pipeline": bool(profile.get("production_texture_pipeline", false)),
		"production_texture_active": production_active,
		"production_texture_slots": Array(profile.get("production_texture_slots", [])),
		"production_texture_slot_count": int(profile.get("production_texture_slot_count", 0)),
		"sample_material_names": Array(profile.get("sample_material_names", [])),
		"sample_material_count": int(profile.get("sample_material_count", 0)),
		"standard_texture_resolution": production_resolution,
		"production_texture_resolution": production_resolution,
		"production_texture_budget_bytes": int(profile.get("production_texture_budget_bytes", 0)),
		"checker_fallback_enabled": true,
		"visible_texture_target": "production_atlas_with_checker_fallback",
		"mapping_policy": str(profile.get("mapping_policy", "")),
		"blending_policy": str(profile.get("blending_policy", "")),
		"texture_import_policy": str(profile.get("texture_import_policy", "")),
		"visual_mode": str(visual_mode),
		"clean_texture_enabled": not clean_albedo_texture_path.is_empty(),
		"clean_albedo_texture_path": clean_albedo_texture_path,
		"clean_triplanar_enabled": clean_triplanar_enabled,
		"clean_material_variation_enabled": clean_material_variation_enabled,
		"clean_material_variation_strength": clean_material_variation_strength,
		"implementation": "terrain_addon_material_applicator",
	}
	return get_material_summary()

func _apply_if_signature_changed() -> bool:
	var signature := _runtime_signature()
	if signature.is_empty() or signature == _auto_apply_signature:
		return false
	_auto_apply_signature = signature
	_auto_apply_count += 1
	apply_materials_now()
	return true

func _repair_missing_materials_if_needed() -> void:
	_audit_frame_count += 1
	if _audit_frame_count < material_audit_interval_frames:
		return
	_audit_frame_count = 0
	if _runtime_signature().is_empty():
		return
	if _material != null and _has_unmaterialized_meshes(_backend_terrain(), _material):
		_auto_apply_count += 1
		apply_materials_now()

func _material_instance() -> ShaderMaterial:
	var resolution := _resolved_texture_resolution()
	if _material == null or _material_texture_resolution != resolution:
		_material = _build_material(resolution)
		_material_texture_resolution = resolution
	return _material

func _build_material(resolution: int) -> ShaderMaterial:
	var shader_material := ShaderMaterial.new()
	shader_material.shader = TERRAIN_SHADER
	var checker := TextureFactory.checker_texture(resolution)
	_texture_checksum = int(checker.get("checksum", 0))
	shader_material.set_shader_parameter("checker_texture", checker.get("texture"))
	var production_resolution := _production_texture_resolution(_material_profile_summary())
	shader_material.set_shader_parameter("terrain_albedo_array", TextureFactory.production_array(production_resolution, &"albedo"))
	shader_material.set_shader_parameter("terrain_normal_array", TextureFactory.production_array(production_resolution, &"normal"))
	shader_material.set_shader_parameter("terrain_roughness_array", TextureFactory.production_array(production_resolution, &"roughness_orm"))
	_apply_visual_mode(shader_material)
	return shader_material

func _apply_visual_mode(shader_material: ShaderMaterial) -> void:
	shader_material.set_shader_parameter("clean_visual_enabled", visual_mode == &"clean")
	shader_material.set_shader_parameter("clean_albedo_color", clean_albedo_color)
	shader_material.set_shader_parameter("clean_texture_world_scale", clean_texture_world_scale)
	shader_material.set_shader_parameter("clean_triplanar_enabled", clean_triplanar_enabled)
	shader_material.set_shader_parameter("clean_triplanar_blend_sharpness", clean_triplanar_blend_sharpness)
	shader_material.set_shader_parameter("clean_material_variation_enabled", clean_material_variation_enabled)
	shader_material.set_shader_parameter("clean_material_variation_strength", clean_material_variation_strength)
	var texture := _load_clean_albedo_texture()
	shader_material.set_shader_parameter("clean_texture_enabled", texture != null)
	if texture != null:
		shader_material.set_shader_parameter("clean_albedo_texture", texture)

func _load_clean_albedo_texture() -> Texture2D:
	if clean_albedo_texture_path.is_empty():
		return null
	var resource := ResourceLoader.load(clean_albedo_texture_path)
	return resource as Texture2D

func _apply_to_meshes(node: Node, material: Material) -> Dictionary:
	var result := {"checked": 0, "updated": 0}
	_apply_to_meshes_recursive(node, material, result)
	return result

func _set_native_material_override(node: Node, material: Material) -> bool:
	if node == null or not node.has_method("set_render_material_override"):
		return false
	node.call("set_render_material_override", material)
	return true

func _apply_to_meshes_recursive(node: Node, material: Material, result: Dictionary) -> void:
	if node is MeshInstance3D:
		var instance := node as MeshInstance3D
		if instance.mesh != null:
			result["checked"] = int(result.get("checked", 0)) + 1
			if instance.material_override != material:
				instance.material_override = material
				result["updated"] = int(result.get("updated", 0)) + 1
	for child in node.get_children():
		if child is Node:
			_apply_to_meshes_recursive(child, material, result)

func _has_unmaterialized_meshes(node: Node, material: Material) -> bool:
	if node == null:
		return false
	if node is MeshInstance3D:
		var instance := node as MeshInstance3D
		if instance.mesh != null and instance.material_override != material:
			return true
	for child in node.get_children():
		if child is Node and _has_unmaterialized_meshes(child, material):
			return true
	return false

func _backend_terrain() -> Node:
	var terrain_world := _terrain_world()
	if terrain_world == null or not terrain_world.has_method("get_backend_terrain"):
		return null
	return terrain_world.call("get_backend_terrain")

func _runtime_signature() -> String:
	var terrain_world := _terrain_world()
	if terrain_world == null or not terrain_world.has_method("get_runtime_metrics"):
		return ""
	var metrics: Dictionary = terrain_world.call("get_runtime_metrics")
	var active_records := int(metrics.get("active_chunk_records", 0))
	var render_resources := int(metrics.get("render_resources", 0))
	var collision_resources := int(metrics.get("collision_resources", 0))
	if active_records <= 0 or render_resources <= 0 or collision_resources <= 0:
		return ""
	var revision := 0
	if terrain_world.has_method("get_world_revision"):
		revision = int(terrain_world.call("get_world_revision"))
	return "%d:%d:%d:%d:%d:%d:%d:%d:%d:%d" % [
		active_records,
		render_resources,
		collision_resources,
		int(metrics.get("viewer_updates", 0)),
		int(metrics.get("edit_replacements", 0)),
		int(metrics.get("queued_render", 0)),
		int(metrics.get("queued_collision", 0)),
		int(metrics.get("pending_chunk_retirements", 0)),
		int(metrics.get("fully_ready_chunk_records", 0)),
		revision,
	]

func _resolved_texture_resolution() -> int:
	var profile := _material_profile_summary()
	var profile_resolution := int(profile.get("texture_resolution", texture_resolution))
	return int(clamp(profile_resolution, 2, 64))

func _texture_bytes(resolution: int) -> int:
	return TextureFactory.texture_bytes(resolution, CHECKER_TEXTURE_BYTES_PER_PIXEL)

func _production_texture_resolution(profile: Dictionary) -> int:
	return int(clamp(int(profile.get("standard_texture_resolution", 64)), 16, 512))

func _terrain_world() -> Node:
	var reference := get_node_or_null(reference_scene_path)
	if reference == null or not reference.has_method("get_terrain_world"):
		return null
	return reference.call("get_terrain_world")

func _material_profile_summary() -> Dictionary:
	var terrain_world := _terrain_world()
	if terrain_world == null:
		return {}
	var profile = terrain_world.get("material_profile")
	if profile != null and profile.has_method("get_contract_summary"):
		var summary := Dictionary(profile.call("get_contract_summary"))
		summary["configured"] = true
		return summary
	return {}
